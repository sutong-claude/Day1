# 比赛归档上下文

## 结论

**可使用，但有 3 项提醒**（COMPLETE_WITH_WARNINGS）

## 比赛

- 平台：代码源新 OJ
- 比赛：2026 CSP-S 复赛赛前模拟赛 day2
- 比赛编号：6ab75554b8c09340fef56fe3
- 页面：https://newoj.daimayuan.top/contest/6ab75554b8c09340fef56fe3/problems
- 当前账号：8859
- 比赛状态：已结束
- 归档时间：2026-09-27T06:23:39.083Z

## 数量核对

- 题目：4/4
- 官方 PDF：0
- 本地阅读 PDF：4
- 有 PDF 的题目：4/4
- 本人提交：0
- 本人源码：0/0
- Archive 跨站恢复：0
- Archive 仍缺：0
- 排行榜行：未选择
- 关注用户命中：0
- 关注用户提交：0
- 关注用户源码：0
- 讨论/澄清：未选择
- 全场提交元数据：0
- 赛中过题：0
- 赛后补题通过：0
- 已通过但时段未判定：0
- 尝试未通过：0
- 完全未提交：4
- 比赛窗口来源：missing（推定值，赛中/赛后判定仅供参考）
- 本地时区：America/New_York（所有 Local 字段按此时区，ISO 字段为 UTC）
- 排名时间线：未生成
- 提交时间范围过滤：未启用
- 分页触顶：0 处

## 目录阅读顺序

1. 先看 `00_总览/完整性报告.md`。
2. 再看 `01_比赛信息/contest.json`。
3. 题面位于 `02_题面/`。
4. 本人提交与源码位于 `03_我的提交/`。
5. 排行榜和关注用户位于 `04_排行榜/`、`05_关注用户/`。
6. 失败原因位于 `99_诊断/错误.json`。

## 用户名归并

- sutong：sutong = sutongg = sutonggg
- CC6bao：CC6bao = cc6bao
- Fanfei：Fanfei = 范飞
- tuantuan88：tuantuan88 = tuantuan8888（旧号：tuantuan8888）
- AtcoderHMC：AtcoderHMC
- HuoTian：HuoTian
- Timmy1224：Timmy1224
- jiangyusong：jiangyusong

AtcoderHMC 与 HuoTian 是两个独立用户，不合并。

## 警告

- Hydro 全场提交元数据：该 Hydro 实例的 /record?tid= 全场提交元数据接口返回 403，多半是较新版本（4.58+）收紧了访问权限，不是脚本故障；排名时间线、最好/最终名次这部分将无法生成，其余归档不受影响。
- 完整性检查：没有识别到本人提交；若本场确实没有提交可忽略此提示

## 错误

- 读取 Hydro 本人提交：HTTP 403：https://newoj.daimayuan.top/record?tid=6ab75554b8c09340fef56fe3&uidOrName=8859
