#include "testlib.h"

#include <bits/stdc++.h>
using namespace std;

static vector<int> readAnswer(InStream &stream, int n) {
    string token = stream.readToken();
    if (token == "-1") return vector<int>{-1};

    if ((int)token.size() == n &&
        token.find_first_not_of("01") == string::npos) {
        vector<int> result(n);
        for (int i = 0; i < n; ++i) result[i] = token[i] - '0';
        return result;
    }

    stream.quitf(_pe, "expected -1 or an n-bit assignment, found '%s'",
                 token.c_str());
}

static bool isNo(const vector<int> &answer) {
    return answer.size() == 1 && answer[0] == -1;
}

static bool isValid(const vector<int> &wolves, const string &direction,
                    const vector<int> &b) {
    const int n = direction.size();
    if ((int)wolves.size() != n) return false;
    vector<int> prefix(n + 1);
    for (int i = 0; i < n; ++i) {
        if (wolves[i] != 0 && wolves[i] != 1) return false;
        if (i && wolves[i - 1] && wolves[i]) return false;
        prefix[i + 1] = prefix[i] + wolves[i];
    }
    for (int i = 0; i < n; ++i) {
        if (wolves[i]) continue;
        int truth = direction[i] == 'L'
                        ? prefix[i]
                        : prefix[n] - prefix[i + 1];
        if (truth != b[i]) return false;
    }
    return true;
}

int main(int argc, char *argv[]) {
    registerTestlibCmd(argc, argv);
    int tests = inf.readInt();
    for (int tc = 1; tc <= tests; ++tc) {
        int n = inf.readInt();
        string direction = inf.readToken();
        vector<int> b(n);
        for (int &value : b) value = inf.readInt();

        vector<int> jury = readAnswer(ans, n);
        vector<int> participant = readAnswer(ouf, n);
        bool juryNo = isNo(jury);
        bool participantNo = isNo(participant);

        if (!juryNo && !isValid(jury, direction, b))
            quitf(_fail, "test case %d: invalid jury assignment", tc);
        if (participantNo) {
            if (!juryNo)
                quitf(_wa, "test case %d: solution exists", tc);
        } else {
            if (!isValid(participant, direction, b))
                quitf(_wa, "test case %d: invalid assignment", tc);
            if (juryNo)
                quitf(_fail, "test case %d: participant disproved jury -1", tc);
        }
    }
    if (!ouf.seekEof()) quitf(_pe, "extra output after all test cases");
    quitf(_ok, "all assignments are valid");
}
