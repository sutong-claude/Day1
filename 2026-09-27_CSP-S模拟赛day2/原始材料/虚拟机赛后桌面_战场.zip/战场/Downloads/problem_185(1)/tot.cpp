#include <bits/stdc++.h>
using namespace std;
string s;
int main () {
    //freopen ("multiply.in", "r", stdin);
    //freopen ("multiply.out", "w", stdout);
    // code
    cin >> s;
    int n = s.size ();
    s = " " + s;
    int ans = 0;
    for (int i = 1; i <= n; i++)
        ans = ans + (s[i] - 48);
    cout << ans << '\n';
    return 0;
}
